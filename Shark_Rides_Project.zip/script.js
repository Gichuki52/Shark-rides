function bookRide() {
    alert('Ride booked successfully!');
}
